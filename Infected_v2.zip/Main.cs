﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using InfinityScript;
using System.Timers;

namespace Infected
{
    public partial class Infected : BaseScript
    {

        public Infected()
        {
            #region 세팅 불러오기
            string setFile = "scripts\\Infected_SET.txt";
            if (File.Exists(setFile))
            {
                using (StreamReader set = new StreamReader(setFile))
                {
                    bool value;
                    int i;
                    float f;

                    while (!set.EndOfStream)
                    {
                        string line = set.ReadLine();
                        if (line.StartsWith("//") || line.Equals(string.Empty)) continue;

                        string[] split = line.Split('=');
                        if (split.Length < 1) continue;

                        string type = split[0];
                        switch (type)
                        {
                            case "SERVER_NAME": SERVER_NAME = split[1]; break;
                            case "ADMIN_NAME": ADMIN_NAME = split[1]; break;
                            case "TEAMNAME_ALLIES": TEAMNAME_ALLIES = split[1]; break;
                            case "TEAMNAME_AXIS": TEAMNAME_AXIS = split[1]; break;
                            case "INFECTED_TIMELIMIT": if (float.TryParse(split[1], out f)) INFECTED_TIMELIMIT = f; break;
                            case "PLAYERWAIT_TIME": if (float.TryParse(split[1], out f)) PLAYERWAIT_TIME = f; break;
                            case "MATCHSTART_TIME": if (float.TryParse(split[1], out f)) MATCHSTART_TIME = f; break;
                            case "SEARCH_TIME": if (int.TryParse(split[1], out i)) SEARCH_TIME = i; break;
                            case "FIRE_TIME": if (int.TryParse(split[1], out i)) FIRE_TIME = i; break;
                            case "BOT_DELAY_TIME": if (int.TryParse(split[1], out i)) BOT_DELAY_TIME = i; break;
                            case "ACTURAL_BOT_COUNT": if (int.TryParse(split[1], out i)) ACTURAL_BOT_COUNT = i; MAX_HUMAN_COUNT = 18 - ACTURAL_BOT_COUNT; break;
                            case "_TEST": if (bool.TryParse(split[1], out value)) _TEST = value; break;
                            case "_DEPLAY_BOT": if (bool.TryParse(split[1], out value)) _DEPLAY_BOT = value; break;
                        }
                    }
                }
            }
            #endregion

            PlayerConnected += Infected_PlayerConnected;
            PlayerDisconnected += Infected_PlayerDisConnected;
            PlayerConnecting += Infected_PlayerConnecting;
            OnNotify("prematch_done", () =>
            {
                PREMATCH_DONE = true;
                Server_SetDvar();
                Server_Hud();

                if (_DEPLAY_BOT) deplayBOTs();
            });

            OnNotify("game_ended", (level) =>
            {
                GAME_ENDED = true;
                end_fire();
                Notify("CLOSE");
                Notify("CLOSE_");
                AfterDelay(13000, () =>
                {
                    ServerEndHud();
                    executeAfter(1900, "map " + NEXT_MAP, "^2NEXT MAP ^7executed");
                });
            });
        }


        void Infected_PlayerConnecting(Entity player)
        {

            if (!PREMATCH_DONE)
            {
                if (player.Name.StartsWith("bot"))
                {
                    Call("kick", player.EntRef);
                    return;
                }
            }
        }
        public override void OnStartGameType()
        {
        }
        void Infected_PlayerConnected(Entity player)
        {
            string name = player.Name;
            int i = 0;

            bool isEndwithNum = int.TryParse(name[name.Length - 1].ToString(), out i);

            if (name.StartsWith("bot") && isEndwithNum)
            {
                Bot_Connected(player);
                return;
            }

            if (player.Name == ADMIN_NAME)
            {
                ADMIN = player;
                if (_TEST)
                {
                    player.Call("thermalvisionfofoverlayon");
                    player.Call("setmovespeedscale", 1.5f);
                    _USE_ADMIN_SAFE = true;
                }
            }

            if (HUMAN_COUNT > MAX_HUMAN_COUNT)
            {
                Utilities.ExecuteCommand("dropclient " + player.EntRef + "SORRY. HUMAN SLOTS ARE OVER. SEE YOU NEXT TIME. [10 BOTS & 8 HUMANS]");
                return;
            }
            HUMAN_COUNT++;
            if (!HUMAN_CONNECTED) HUMAN_CONNECTED = true;
            if (isSurvivor(player))
            {
                Client_init_GAME_SET(player);
            }
            else
            {
                player.SetField("AX_WEP", 0);
                player.Call("suicide");
            }

            player.SpawnedPlayer += () =>
            {
                var aw = player.GetField<int>("AX_WEP");
                if (aw == 0)
                {
                    AxisHud(player);
                    if (_DISABLE_MELEE_OF_INFECTED) Utilities.RawSayTo(player, "^2[ ^7DISABLED ^2] Melee of the Infected");

                    player.AfterDelay(t1, p => AxisWeapon_by_init(player));
                }
                else
                {
                    var byAttack = player.GetField<bool>("byAttack");

                    if (byAttack) AxisWeapon_by_Attack(player, aw);
                    else AxisWeapon_by_init(player);
                }
            };
        }

        void Infected_PlayerDisConnected(Entity player)
        {
            // 봇 타겟리스트에서 접속 끊은 사람 제거
            if (human_List.Contains(player))
            {
                human_List.Remove(player);
                HUMAN_COUNT--;
            }
            if (HUMAN_COUNT == 0 && !GAME_ENDED) HUMAN_CONNECTED = false;
        }

        public override void OnExitLevel()
        {
            foreach(Entity bot in BOTs_List)
            {
                Call("kick", bot.EntRef);
            }
            if (NEXT_MAP == null) NEXT_MAP = "";
            else NEXT_MAP = "map" + NEXT_MAP;
            Utilities.ExecuteCommand(NEXT_MAP);
        }
    }
}

