﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using InfinityScript;

namespace Infected
{

        public class P  //PerkLIST
    {

        public static string[] PL =
        {
"specialty_scavenger",
"specialty_quickdraw",
"specialty_stalker",
"specialty_longersprint",
"specialty_fastreload",
"specialty_paint",
"specialty_quieter",
"specialty_blindeye",
"specialty_coldblooded",
"specialty_blastshield",
"specialty_hardline"
};

        public static string[] DL =
        {

"specialty_ironlungs",
"specialty_steadyaim",
"specialty_bombsquad",
"specialty_twoprimaries",

};
        public static string[] CL =
        {
"specialty_longerrange",
"specialty_reducedsway",
"specialty_lightweight",
"specialty_sharp_focus",
"specialty_bulletpenetration",
"specialty_moredamage"
};


    }

}
