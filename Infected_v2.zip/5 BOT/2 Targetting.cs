﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using InfinityScript;
using System.Diagnostics;
using System.Timers;

namespace Infected
{
    public partial class Infected
    {
        //봇 스폰 시작
        void spawnd_bot(Entity bot)
        {
            int num = bot.GetField<int>("bid");
            if (num == -1) return;
            bot_search[num] = false;
            bot_fire[num] = false;
            bot.SetField("tNum", -1);

            var o = bot.Origin;//스폰 딜레이 for protecting server_down
            bot.Call("setmovespeedscale", 0);//setmovespeedscale
            bot.Call("allowspectateteam", "freelook", true);//allowspectateteam
            bot.SetField("sessionstate", "spectator");

            bot.AfterDelay(BOT_DELAY_TIME, b =>
            {
                bot_search[num] = true;
                bot_fire[num] = true;

                b.Call("allowspectateteam", "freelook", false);//allowspectateteam
                b.SetField("sessionstate", "playing");
                bot.Call("setorigin", o);
                b.Call("setmovespeedscale", 1);//setmovespeedscale
                var weapon = b.CurrentWeapon;
                b.Call("setweaponammostock", weapon, 0);

                start_bot_search(b, num, weapon);
            });

        }

        //봇 목표물 찾기 루프
        void start_bot_search(Entity bot, int num, string weapon)
        {
            bot.OnInterval(SEARCH_TIME, b =>
            {
                if (!HUMAN_CONNECTED)
                {
                    bot_fire[num] = false;
                    return true;
                }
                //if(_TEST)print(bot.Name + bot_search[num]);

                if (!bot_search[num]) return false;

                var targetNum = bot.GetField<int>("tNum");

                if (targetNum != -1)//이미 타겟을 찾은 경우
                {
                    //if(_TEST)printToAdmin("target to ADMIN : "+bot.Name);

                    Entity t = Call<Entity>(52, targetNum);//getentbynum
                    if (t != null)
                    {
                        if (isSurvivor(t))
                        {
                            var POD = t.Origin.DistanceTo(bot.Origin);
                            if (POD < 600)
                            {
                                return true;
                            }
                        }
                    }

                    //타겟과 거리가 멀어진 경우, 타겟 제거
                    bot.SetField("tNum", -1);
                    bot_fire[num] = false;
                    bot.Call(33468, weapon, 0);//setweaponammoclip
                }

                //타겟 찾기 시작
                foreach (Entity human in human_List)
                {
                    var POD = human.Origin.DistanceTo(bot.Origin);

                    if (POD < 600)
                    {
                        bot.SetField("tNum", human.EntRef);
                        bot_fire[num] = true;


                        b.OnInterval(FIRE_TIME, bb =>
                        {
                            if (!bot_fire[num]) return false;

                            var ho = human.Origin; ho.Z -= 50;

                            Vector3 temp_ = Call<Vector3>(247, ho - bb.Origin);//vectortoangles
                            bb.Call(33531, temp_);//SetPlayerAngles
                            bb.Call(33468, weapon, 5);//setweaponammoclip
                            return true;
                        });

                        return true;
                    }

                }

                return true;

            });

        }

        void end_fire()
        {
            for (int i = 0; i < 17; i++)
            {
                bot_search[i] = bot_search[i] = false;
            }
        }


    }
}
