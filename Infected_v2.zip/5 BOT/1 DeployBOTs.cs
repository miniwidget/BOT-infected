﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using InfinityScript;
using System.Diagnostics;
using System.Timers;

namespace Infected
{
    public partial class Infected
    {
        List<Entity> human_List = new List<Entity>();
        List<Entity> BOTs_List = new List<Entity>();
        protected bool[] bot_search = new bool[18];
        protected bool[] bot_fire = new bool[18];
        //protected bool[] bot_class = new bool[18];
        bool isSurvivor(Entity player) { return player.GetField<string>("sessionteam") == "allies"; }//sessionteam
        //Entity FINAL_BOT;
        #region 게임 시작 후, 봇 불러오기 //실패 시, 맵 다시 시작
        void deplayBOTs()
        {

            OnInterval(500, () =>
            {
                if (OVERFLOW_BOT) return false;
                if (CONNECTED_BOT_COUNT >= ACTURAL_BOT_COUNT || CONNECTED_BOT_COUNT > 10) return false;
                if (FAIL_COUNT > 5)
                {
                    deplayBOTs_map_init();
                    return false;
                }
                Entity b = Utilities.AddTestClient();

                if (b == null)
                {
                    KickBOTsAll();
                    CONNECTED_BOT_COUNT = 0;
                    if (_TEST) print("죽은 봇 발견!!!");
                    AfterDelay(t1, () => deplayBOTs());
                    FAIL_COUNT++;
                    return false;
                }

                CONNECTED_BOT_COUNT++;

                return true;

            });
        }
        void deplayBOTs_map_init()
        {
            KickBOTsAll();
            // Call("iPrintlnBold", "");
            HudElem staticBG = HudElem.NewHudElem();
            staticBG.HorzAlign = "fullscreen";
            staticBG.VertAlign = "fullscreen";
            staticBG.SetShader("black", 640, 480);
            staticBG.Foreground = true;
            staticBG.HideWhenInMenu = false;
            staticBG.Alpha = 0;
            staticBG.Call("fadeovertime", 5f);
            staticBG.Alpha = 1f;

            int transitiontime = 100;
            int duration = 5000;
            int decayduration = 2000;

            HudElem END = HudElem.CreateServerFontString("default", 2f);
            END.SetPoint("CENTER", "CENTER", 0, 100);
            END.Foreground = true;
            END.HideWhenInMenu = false;
            END.Alpha = 1f;
            END.Call("setpulsefx", transitiontime, duration, decayduration);
            END.SetText("SOMETHING WRONG HAPPEND.RESTART MAP in 5 seconds");

            AfterDelay(t5, () =>
            {
                Utilities.ExecuteCommand("fast_restart");
            });
        }
        #endregion

        #region Bot_Connected
        bool FINAL_BOT_FOUND;

        void Bot_Connected(Entity bot)
        {
            string message = null;
            if (CONNECTED_BOT_COUNT >= ACTURAL_BOT_COUNT || CONNECTED_BOT_COUNT > 10)
            {
                OVERFLOW_BOT = true;
                Call("kick", bot.EntRef);
                CONNECTED_BOT_COUNT = 100;
                return;
            }
            if (!PREMATCH_DONE)//시작 전, 미리 봇이 접속한 경우
            {
                CONNECTED_BOT_COUNT++;
                message = "||PREMATCH";
            }
            var i = BOTs_List.Count;
            if (i == -1)
            {
                Call("kick", bot.EntRef);
                return;
            }

            bot.Name = "bot" + CONNECTED_BOT_COUNT;
            bot.SetField("bid", BOTs_List.Count);
            bot.SetField("tNum", -1);
            print(bot.Name + "CONNECTED★★★" + message + CONNECTED_BOT_COUNT + "//" + BOTs_List.Count);
            BOTs_List.Add(bot);

            bot.SpawnedPlayer += () => spawnd_bot(bot);

            bot.AfterDelay(10000, p =>
            {
                if (bot.GetField<string>("sessionteam") == "axis")
                {
                    p.AfterDelay(5000, x => bot.Call("suicide"));
                }
                else
                {
                    if (!FINAL_BOT_FOUND && !HUMAN_CONNECTED)
                    {
                        FINAL_BOT_FOUND = true;
                        return;
                    }
                    bot.Call("suicide");
                }

            });

        }
        #endregion

        void changeClass(string cls)
        {

        }
    }
}
